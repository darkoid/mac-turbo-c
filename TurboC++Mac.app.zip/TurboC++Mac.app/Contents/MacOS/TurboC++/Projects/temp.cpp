#include <stdio.h>
#include <conio.h>

int main()
{
	clrscr();
	printf("This is a sample c/cpp file.\n");
	printf("Made by Darkoid\n");
	getch();
	return 0;
}